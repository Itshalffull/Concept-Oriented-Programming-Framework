# Kit Manifest Reference

Complete specification for `kit.yaml` — the manifest file that declares a concept kit's contents, type alignments, sync tiers, and external concept references.

## File Location

```
kits/<kit-name>/kit.yaml
```

## Full Manifest Structure

```yaml
# Kit metadata
kit:
  name: content-management
  version: 0.1.0
  description: >
    Drupal-style entity/field/relation system for structured content.
    Provides typed entities with attachable fields and inter-entity
    relationships, with cascade lifecycle management.

# Concepts included in this kit
concepts:
  ConceptName:
    spec: ./concept-name.concept
    params:
      T: { as: shared-type-tag, description: "Human-readable description" }

# Syncs bundled with the kit
syncs:
  required:
    - path: ./syncs/sync-name.sync
      description: >
        Why this sync is required. What breaks without it.

  recommended:
    - path: ./syncs/sync-name.sync
      name: SyncRuleName
      description: >
        What this sync does. How apps can override it.

# External concepts from other kits that this kit's syncs reference.
# Required by default; set optional: true for conditional syncs
# that only load when the named kit is present.
uses:
  - kit: other-kit-name
    concepts:
      - name: ConceptName
        params:
          T: { as: shared-type-tag }
  - kit: another-kit
    optional: true
    concepts:
      - name: OptionalConcept
    syncs:
      - path: ./syncs/conditional-sync.sync
        description: >
          Only loads if another-kit is present.

# Optional: other kits this kit requires
dependencies: []
```

## Section Details

### `kit` (required)

Kit-level metadata.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Kit name, kebab-case. Used in deployment manifests. |
| `version` | string | Yes | Semver version string. |
| `description` | string | Yes | Multi-line description. First sentence should summarize. |

### `concepts` (required)

Map of concept names to their specs and parameter alignments.

```yaml
concepts:
  Entity:
    spec: ./entity.concept
    params:
      E: { as: entity-ref, description: "Reference to an entity" }

  Field:
    spec: ./field.concept
    params:
      F: { as: field-ref, description: "Reference to a field instance" }
      T: { as: entity-ref }    # Aligned with Entity's E
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `spec` | string | Yes | Relative path to the `.concept` file |
| `params` | map | Yes | Type parameter declarations with `as` alignment tags |

**Param entry fields:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `as` | string | Yes | Shared type identity tag (e.g., `entity-ref`, `user-ref`) |
| `description` | string | No | Human-readable description of what this parameter represents |

### `syncs` (required)

Grouped by tier — `required` and `recommended`.

**Required syncs:**

```yaml
syncs:
  required:
    - path: ./syncs/cascade-delete-fields.sync
      description: >
        When an entity is deleted, all attached fields are detached
        and deleted. Without this, the Field concept accumulates
        orphaned records.
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `path` | string | Yes | Relative path to the `.sync` file |
| `description` | string | Yes | Why this sync is required — what breaks without it |

**Recommended syncs:**

```yaml
syncs:
  recommended:
    - path: ./syncs/default-title-field.sync
      name: DefaultTitleField
      description: >
        When a node is created, automatically attach a title field.
        Override if your app uses a different title convention.
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `path` | string | Yes | Relative path to the `.sync` file |
| `name` | string | Yes | The sync rule name — used for overrides and disables |
| `description` | string | Yes | What it does and how apps might customize it |

**Why `name` is required for recommended but not required syncs**: Apps override recommended syncs by declaring a sync with the same name. Required syncs can't be overridden, so naming is informational only.

### `uses` (optional)

Declares external concepts from other kits that this kit's syncs reference. The `copf kit validate` command checks that all concept references in syncs are either local concepts, declared in `uses`, or built-in (e.g., `Web`).

Each entry is **required by default** — the external kit must be present for this kit to function. Set `optional: true` for conditional entries whose syncs only load when the named kit is present (what was previously handled by a separate `integrations` section).

**Required uses** (default):

```yaml
uses:
  - kit: auth
    concepts:
      - name: User
        params:
          U: { as: user-ref }
      - name: JWT
```

**Optional uses** (conditional syncs):

```yaml
uses:
  - kit: auth
    optional: true
    concepts:
      - name: User
      - name: JWT
    syncs:
      - path: ./syncs/entity-ownership.sync
        description: >
          When a user creates an entity, record ownership.
          Only loads if the auth kit is present.
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `kit` | string | Yes | Name of the external kit providing the concepts |
| `optional` | boolean | No | When `true`, the entry's syncs only load if the named kit is present. Default: `false` (required). |
| `concepts` | list | Yes | Concept entries from that kit |
| `syncs` | list | No | Sync files that depend on the external kit. Primarily used with `optional: true`. |

**Concept entry fields:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Concept name as referenced in syncs (e.g., `User`) |
| `params` | map | No | Type parameter alignment using `as` tags, same format as the `concepts` section |

**Relationship to `dependencies`:**

| Section | Purpose |
|---------|---------|
| `dependencies` | Kit-level version constraint |
| `uses` | Concept-level declarations — which external concepts this kit's syncs reference |

A required `uses` entry implies the external kit must be present. Consider also listing it in `dependencies` for version constraint enforcement.

**Validation behavior:**
- If a `uses` section is present, syncs referencing undeclared external concepts produce **errors**
- If no `uses` section exists, undeclared external references produce **warnings** (backward compatibility)
- Optional uses syncs are exempt from strict validation — they only load conditionally
- Concepts declared in `uses` but never referenced by any sync produce a **warning**
- A required `uses` kit not listed in `dependencies` produces a **warning**

### `dependencies` (optional)

Other kits that must be present for this kit to function:

```yaml
dependencies:
  - name: auth
    version: ">=0.1.0"
```

Most kits have no dependencies. Use optional `uses` entries (conditional enhancement) over dependencies (hard requirement) when possible.

## App-Side Usage

Apps reference kits in their deployment manifest (`deploy.yaml`):

```yaml
kits:
  - name: content-management
    path: ./kits/content-management
    overrides:
      # Replace DefaultTitleField with a custom sync
      DefaultTitleField: ./syncs/custom-title.sync
    disable:
      # Don't auto-update timestamps
      - UpdateTimestamp

  - name: auth
    path: ./kits/auth
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Kit name (matches `kit.name` in manifest) |
| `path` | string | Yes | Relative path to kit directory |
| `overrides` | map | No | Map of sync name → replacement sync file path |
| `disable` | list | No | List of recommended sync names to disable |

**Override**: The app provides a different sync with the same name. The app's version replaces the kit's version.

**Disable**: The app removes the sync entirely. Only works for recommended syncs — the compiler errors if you try to disable a required sync.

## Validation

The `copf kit validate` command checks:

1. `kit.yaml` exists and is parseable
2. All referenced `.concept` files exist and parse successfully
3. All referenced `.sync` files exist and parse successfully
4. Sync tier annotations match the manifest declarations
5. Type parameter alignment consistency (advisory warnings)
6. Sync concept references — all concepts referenced in syncs must be local, declared in `uses`, or built-in (`Web`)
7. Optional uses syncs are exempt from strict reference checking (they only load conditionally)

```bash
npx tsx tools/copf-cli/src/index.ts kit validate kits/<kit-name>
```

Output:
```
Validating kit: kits/content-management

  Kit: content-management
  Uses: 2 external concept(s) from 1 kit
    [OK] User (from auth)
    [OK] JWT (from auth)
  Concepts: 4
    [OK] Entity (entity.concept)
    [OK] Field (field.concept)
    [OK] Relation (relation.concept)
    [OK] Node (node.concept)
  Syncs: 7
    [OK] CascadeDeleteFields (syncs/cascade-delete-fields.sync)
    [OK] CascadeDeleteRelations (syncs/cascade-delete-relations.sync)
    ...
  Sync tiers: 3 required, 3 recommended

Kit is valid.
```
